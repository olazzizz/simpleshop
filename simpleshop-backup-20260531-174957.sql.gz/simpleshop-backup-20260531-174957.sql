--
-- PostgreSQL database dump
--

\restrict hV3EFA80nf2IWQRDDD5Q9OeKIkNaVa9Gr3UCImB6biXu62nQ5X038yducckrq55

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.cart_items (
    user_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.cart_items OWNER TO simpleshop;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price real NOT NULL
);


ALTER TABLE public.order_items OWNER TO simpleshop;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleshop
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO simpleshop;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleshop
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total real NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.orders OWNER TO simpleshop;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleshop
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO simpleshop;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleshop
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    "desc" text NOT NULL,
    price real NOT NULL,
    rating real NOT NULL,
    reviews integer NOT NULL,
    emoji text NOT NULL,
    discount integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.products OWNER TO simpleshop;

--
-- Name: users; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO simpleshop;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: simpleshop
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO simpleshop;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: simpleshop
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wishlist_items; Type: TABLE; Schema: public; Owner: simpleshop
--

CREATE TABLE public.wishlist_items (
    user_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.wishlist_items OWNER TO simpleshop;

--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.cart_items (user_id, product_id, quantity) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.order_items (id, order_id, product_id, quantity, unit_price) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.orders (id, user_id, total, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.products (id, name, category, "desc", price, rating, reviews, emoji, discount) FROM stdin;
1	Wireless Headphones	Audio	Premium sound with active noise cancellation. 30-hour battery.	79.99	4.8	342	🎧	15
2	Mechanical Keyboard	Input	Tactile keys, RGB backlight, USB-C. Hot-swappable switches.	129	4.9	521	⌨️	0
3	Portable Charger	Power	20,000 mAh, fast-charge, dual USB. Lightweight design.	39.99	4.6	218	🔋	20
4	Smart Watch	Wearable	Heart rate, GPS, 7-day battery. Water-resistant.	199	4.7	459	⌚	0
5	Desk Lamp	Lighting	Adjustable brightness, warm/cool tones. Touch control.	34.99	4.4	156	💡	25
6	Webcam 4K	Video	Auto-focus, built-in mic, plug-and-play. Wide angle.	89	4.5	287	📷	10
7	Mouse Pad XL	Input	Non-slip base, stitched edges, 90×40 cm. Premium cloth.	24.99	4.3	95	🖱️	0
8	USB-C Hub	Connectivity	7-in-1: HDMI, SD card, USB-A ×3, PD. Thunderbolt 3.	49.99	4.6	331	🔌	0
9	Bluetooth Speaker	Audio	360° sound, 12-hour battery. IPX7 waterproof.	59.99	4.7	412	🔊	15
10	Phone Stand	Accessories	Adjustable angle, premium aluminum. Non-slip feet.	14.99	4.2	78	📱	30
11	USB-C Cable	Connectivity	High-speed data transfer. 2m length, durable.	9.99	4.4	203	🔗	0
12	Wireless Mouse	Input	Precision tracking, ergonomic design. 18-month battery.	44.99	4.5	389	🖐️	18
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.users (id, username, email, password_hash, created_at) FROM stdin;
1	onofriol	onofrio@email.com	$2a$10$g08MRoWZYnX7.4Ei/nDJJuSrGDgtj0aL8SjIZW2Hde3G58uMN1XBm	2026-05-31 15:42:37.653001+00
\.


--
-- Data for Name: wishlist_items; Type: TABLE DATA; Schema: public; Owner: simpleshop
--

COPY public.wishlist_items (user_id, product_id) FROM stdin;
1	4
1	3
1	2
1	1
\.


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: simpleshop
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: simpleshop
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: simpleshop
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (user_id, product_id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wishlist_items wishlist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_pkey PRIMARY KEY (user_id, product_id);


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: cart_items cart_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: wishlist_items wishlist_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: wishlist_items wishlist_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: simpleshop
--

ALTER TABLE ONLY public.wishlist_items
    ADD CONSTRAINT wishlist_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict hV3EFA80nf2IWQRDDD5Q9OeKIkNaVa9Gr3UCImB6biXu62nQ5X038yducckrq55

